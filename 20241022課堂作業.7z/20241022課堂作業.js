let font;  //載入字型文字
let points = [];  //轉成點狀文字
let angle = 0
let r = 10
// ==================================================
function preload(){  //在執行setup()前，必須先做此函數執行，主要先載入字型
    //為載入在fonts資料夾內的KleeOne-Regular.ttf字型
    font = loadFont("fonts/KleeOne-Regular.ttf") 
}
//===================================================

function setup() {  //設定環境
  createCanvas(windowWidth, windowHeight);  //設定畫布的寬高
  angleMode((DEGREES))  //設定三角函數的角度用0~360
  background("#d8e2dc")  //背景顏色
  points = font.textToPoints("TKUET", -300, 80, 200, {
    sampleFactor:0.1
  }); //轉成文字圖檔，放在(0, 200)位置，圖形大小為200，sampleFactor為點數距離大小。值越小代表點數越少
  //for (let i=0; i<points.length-1; i++) { 
    //text(str(i),points[i].x,points[i].y)
    //fill("#ffcad4")
    //noStroke()
    //strokeWeight(1)  //線條的粗細
    //ellipse(points[i].x+sin(angle),points[i].y,10)
    //stroke("#f4acb7")  //線條的顏色
    //strokeWeight(5)  //線條的粗細
    //line(points[i].x,points[i].y,points[i+1].x,points[i+1].y)  //畫線，兩個點構成一條線
    //畫線，兩個點第一個點(points[i].x,points[i].y)，第二個點(points[i+1].x,points[i+1].y)
  
 angle = angle+10
}

function draw() {  //畫圖，每秒會進入執行程式60次
  background("#d8e2dc");
  //textSize(30)
  //text(mouseX+";"+mouseY,width/2,height/2)

  translate(width/2,height/2)  //把原本原點(0,0)在左上角，改為到畫布中心點
  rotate((frameCount)%360)  //依照frameCount除以360求餘數
  for (let i=0; i<points.length-1; i++) { 
    //text(str(i),points[i].x,points[i].y)
    //fill("#ffcad4")
    //noStroke()
    //strokeWeight(1)  //線條的粗細
    //ellipse(points[i].x+r*sin(angle+i*20),points[i].y+r*sin(angle+i*20),10)
    stroke("#f4acb7")  //線條的顏色
    strokeWeight(5)  //線條的粗細
    line(points[i].x+r*sin(angle+i*10),points[i].y+r*sin(angle+i*10),points[i+1].x+r*sin(angle+i*10),points[i+1].y+r*sin(angle+i*10))  //畫線，兩個點構成一條線
    //畫線，兩個點第一個點(points[i].x,points[i].y)，第二個點(points[i+1].x,points[i+1].y)
 } 
 angle = angle+10
}
